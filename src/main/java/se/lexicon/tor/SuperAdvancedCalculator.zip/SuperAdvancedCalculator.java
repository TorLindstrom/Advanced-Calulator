package se.lexicon.tor;

import java.util.Scanner;

public class SuperAdvancedCalculator {

    public static void main(String[] args) {

        //talks to user
        Helpers.writeL("\n---Opening Tor's Calculator---\n---version eX.0.7---\n\n"); //println

        Helpers.writeL("Available operators are: '+' '-' '/' '*' 'sqrt' (squareroot) 'power' (power of)\n");

        Helpers.writeL("Write 'quit' if you wish to exit\n");


        while (true) { //keeps running the whole program

            String rawLine = Helpers.askAdvLine(); //input math line

            if (rawLine.equals("QUIT")) {
                Helpers.writeL("\n---Exiting Tor's Calculator---\n---version eX.0.7---");
                break;
            } else {
                //call for solution and prints it
                Helpers.writeL(EquationHelpers.solveWithParenthesis(rawLine));
            }
        }
    }
}
